package org.jetbrains.plugins.template.settings

import com.intellij.credentialStore.CredentialAttributes
import com.intellij.credentialStore.Credentials
import com.intellij.credentialStore.generateServiceName
import com.intellij.ide.passwordSafe.PasswordSafe
import com.intellij.openapi.components.*

@Service(Service.Level.APP)
@State(
    name = "DeepSeekSettings",
    storages = [Storage("DeepSeekSettings.xml")]
)
final class DeepSeekSettingsService : PersistentStateComponent<DeepSeekSettingsService.State> {

    data class State(
        var model: String = "deepseek-chat",
        var maxTokens: Int = 1024,
        var temperature: Double = 0.2,
        var onlyInComments: Boolean = false
    )

    private var state = State()

    override fun getState(): State = state

    override fun loadState(state: State) {
        this.state = state
    }

    private fun apiKeyAttributes(): CredentialAttributes {
        return CredentialAttributes(
            generateServiceName("DeepSeekInlineCompletion", "apiKey")
        )
    }

    fun getApiKey(): String {
        return PasswordSafe.instance.getPassword(apiKeyAttributes()) ?: ""
    }

    fun setApiKey(value: String) {
        val attrs = apiKeyAttributes()
        if (value.isBlank()) {
            PasswordSafe.instance.set(attrs, null)
        } else {
            PasswordSafe.instance.set(attrs, Credentials("DeepSeek", value))
        }
    }

    companion object {
        fun getInstance(): DeepSeekSettingsService =
            service()
    }
}