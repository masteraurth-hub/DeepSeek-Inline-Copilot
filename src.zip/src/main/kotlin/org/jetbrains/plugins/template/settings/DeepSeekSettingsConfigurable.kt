package org.jetbrains.plugins.template.settings

import com.intellij.openapi.options.Configurable
import com.intellij.ui.components.JBPasswordField
import com.intellij.ui.dsl.builder.AlignX
import com.intellij.ui.dsl.builder.bindSelected
import com.intellij.ui.dsl.builder.panel
import javax.swing.JComponent
import javax.swing.JSpinner
import javax.swing.JTextField
import javax.swing.SpinnerNumberModel

class DeepSeekSettingsConfigurable : Configurable {
    private val settings = DeepSeekSettingsService.getInstance()

    private val apiKeyField = JBPasswordField()
    private val modelField = JTextField()
    private val maxTokensSpinner = JSpinner(SpinnerNumberModel(1024, 1, 8192, 1))
    private val temperatureSpinner = JSpinner(SpinnerNumberModel(0.2, 0.0, 2.0, 0.1))
    private var onlyInComments = false

    private val mainPanel = panel {
        row("DeepSeek API Key:") {
            cell(apiKeyField).align(AlignX.FILL).resizableColumn()
            comment("输入你自己的 DeepSeek API Key")
        }
        row("Model:") {
            cell(modelField).align(AlignX.FILL).resizableColumn()
        }
        row("Max tokens:") {
            cell(maxTokensSpinner)
        }
        row("Temperature:") {
            cell(temperatureSpinner)
        }
        row {
            checkBox("仅在注释中触发补全")
                .bindSelected(::onlyInComments)
        }
    }

    override fun getDisplayName(): String = "DeepSeek Completion"

    override fun createComponent(): JComponent = mainPanel

    override fun reset() {
        apiKeyField.text = settings.getApiKey()
        modelField.text = settings.state.model
        maxTokensSpinner.value = settings.state.maxTokens
        temperatureSpinner.value = settings.state.temperature
        onlyInComments = settings.state.onlyInComments
    }

    override fun isModified(): Boolean {
        return String(apiKeyField.password) != settings.getApiKey() ||
                modelField.text != settings.state.model ||
                (maxTokensSpinner.value as Int) != settings.state.maxTokens ||
                ((temperatureSpinner.value as Number).toDouble() != settings.state.temperature) ||
                onlyInComments != settings.state.onlyInComments
    }

    override fun apply() {
        settings.setApiKey(String(apiKeyField.password))
        settings.loadState(
            DeepSeekSettingsService.State(
                model = modelField.text.ifBlank { "deepseek-chat" },
                maxTokens = maxTokensSpinner.value as Int,
                temperature = (temperatureSpinner.value as Number).toDouble(),
                onlyInComments = onlyInComments
            )
        )
    }
}