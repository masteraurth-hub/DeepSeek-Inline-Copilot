package org.jetbrains.plugins.template.settings

import com.intellij.codeInsight.inline.completion.*
import com.intellij.codeInsight.inline.completion.elements.InlineCompletionGrayTextElement
import com.intellij.credentialStore.CredentialAttributes
import com.intellij.ide.passwordSafe.PasswordSafe
import com.intellij.openapi.diagnostic.Logger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withContext
import java.net.URI
import java.net.http.HttpClient
import java.net.http.HttpRequest
import java.net.http.HttpResponse
import java.time.Duration



class GeminiInlineCompletionProvider : InlineCompletionProvider {
    private val LOG = Logger.getInstance(GeminiInlineCompletionProvider::class.java)

    // 初始化 HTTP 客户端
    private val httpClient = HttpClient.newBuilder()
        .connectTimeout(Duration.ofSeconds(30))
        .build()

    override val id: InlineCompletionProviderID = InlineCompletionProviderID("DeepSeekInlineCompletion")

    // 触发条件：这里可以后续加入判断，比如只有在写注释时才触发
    override fun isEnabled(event: InlineCompletionEvent): Boolean {
        LOG.warn("=== isEnabled CALLED ===")
        return true
    }

    override suspend fun getSuggestion(request: InlineCompletionRequest): InlineCompletionSuggestion {
        LOG.warn("=== PROVIDER ENTERED ===")

        val editor = request.editor
        val document = editor.document
        val offset = request.endOffset

        val textBeforeCaret = document.getText(com.intellij.openapi.util.TextRange(0, offset))
        val contextText = if (textBeforeCaret.length > 3000) textBeforeCaret.takeLast(3000) else textBeforeCaret

        return InlineCompletionSuggestion.Default(flow {
            try {
                LOG.warn("=== ABOUT TO CALL DEEPSEEK ===")

                val generatedCode = withContext(Dispatchers.IO) {
                    fetchFromDeepSeek(contextText)
                }

                LOG.warn("=== DEEPSEEK RETURNED len=${generatedCode.length} ===")

                if (generatedCode.isNotEmpty()) {
                    emit(InlineCompletionGrayTextElement(generatedCode))
                }
            } catch (e: Exception) {
                LOG.error("调用 DeepSeek API 失败", e)
            }
        })
    }

    // 网络请求方法
    private fun fetchFromDeepSeek(context: String): String {
        val apiKey = DeepSeekSettingsService.getInstance().getApiKey()

        if (apiKey.isEmpty()) {
            LOG.warn("未配置 DeepSeek API Key，无法生成补全。")
            return ""
        }

        val systemPrompt =
            "你是 IDE 代码生成助手。请根据用户上下文，一次性输出完整、可运行的代码。不要解释，不要 Markdown，只输出代码。"

        val requestBody = """
        {
            "model": "deepseek-chat",
            "messages": [
                {"role": "system", "content": "${jsonEscape(systemPrompt)}"},
                {"role": "user", "content": "${jsonEscape(context)}"}
            ],
            "stream": false,
            "max_tokens": 2048,
            "temperature": 0.2
        }
    """.trimIndent()

        val request = HttpRequest.newBuilder()
            .uri(URI.create("https://api.deepseek.com/chat/completions"))
            .timeout(Duration.ofSeconds(120))
            .header("Content-Type", "application/json")
            .header("Authorization", "Bearer $apiKey")
            .POST(HttpRequest.BodyPublishers.ofString(requestBody))
            .build()

        val response = httpClient.send(request, HttpResponse.BodyHandlers.ofString())
        val body = response.body()

        LOG.warn("📦 [DeepSeek] 状态码: ${response.statusCode()}")
        LOG.warn("📦 [DeepSeek] 原始响应预览: ${body.take(1000)}")

        if (response.statusCode() != 200) {
            LOG.warn("DeepSeek API 报错: 状态码 ${response.statusCode()}, 响应: $body")
            return ""
        }

        return extractContentFromResponse(body)
    }

    private fun jsonEscape(text: String): String {
        return buildString {
            text.forEach { ch ->
                when (ch) {
                    '\\' -> append("\\\\")
                    '"' -> append("\\\"")
                    '\n' -> append("\\n")
                    '\r' -> append("\\r")
                    '\t' -> append("\\t")
                    '\b' -> append("\\b")
                    '\u000C' -> append("\\f")
                    else -> append(ch)
                }
            }
        }
    }

    private fun extractContentFromResponse(body: String): String {
        try {
            val contentKey = "\"content\":\""
            val startIndex = body.indexOf(contentKey)
            if (startIndex == -1) return ""

            val contentStart = startIndex + contentKey.length

            // 纯文本线性扫描，寻找未被转义的结束双引号（彻底告别正则栈溢出）
            var contentEnd = -1
            for (i in contentStart until body.length) {
                if (body[i] == '"') {
                    var backslashCount = 0
                    var j = i - 1
                    while (j >= contentStart && body[j] == '\\') {
                        backslashCount++
                        j--
                    }
                    if (backslashCount % 2 == 0) {
                        contentEnd = i
                        break
                    }
                }
            }

            if (contentEnd == -1) return ""

            var code = body.substring(contentStart, contentEnd)
                .replace("\\n", "\n")
                .replace("\\r", "\r")
                .replace("\\t", "\t")
                .replace("\\\"", "\"")
                .replace("\\\\", "\\")
                .trim()

            // 强力移除大模型带上的 Markdown 代码块标记
            code = code.replace(Regex("^```[a-zA-Z]*\\n?"), "")
            code = code.replace(Regex("\\n?```$"), "")

            return code.trim()
        } catch (e: Exception) {
            return ""
        }
    }
}

